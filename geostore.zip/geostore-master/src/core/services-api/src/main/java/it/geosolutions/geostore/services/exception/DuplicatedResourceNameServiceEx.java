package it.geosolutions.geostore.services.exception;

public class DuplicatedResourceNameServiceEx extends GeoStoreServiceException {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4463223126322915755L;

	public DuplicatedResourceNameServiceEx(String message) {
		super(message);
	}
	
}
